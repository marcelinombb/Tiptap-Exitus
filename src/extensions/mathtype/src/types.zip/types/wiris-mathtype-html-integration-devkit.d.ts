// src/types/wiris-mathtype-html-integration-devkit.d.ts

declare module '@wiris/mathtype-html-integration-devkit/src/configuration' {
  export class Configuration {}
}

declare module '@wiris/mathtype-html-integration-devkit/src/util' {
  export class Util {}
}

declare module '@wiris/mathtype-html-integration-devkit/src/integrationmodel' {
  import Configuration from '@wiris/mathtype-html-integration-devkit/src/configuration'
  import type Core from '@wiris/mathtype-html-integration-devkit/src/core.src'
  import Image from '@wiris/mathtype-html-integration-devkit/src/image'
  import type Listeners from '@wiris/mathtype-html-integration-devkit/src/listeners'
  import ServiceProvider from '@wiris/mathtype-html-integration-devkit/src/serviceprovider'
  import Telemeter from '@wiris/mathtype-html-integration-devkit/src/telemeter'
  import Util from '@wiris/mathtype-html-integration-devkit/src/util'
  import warnIcon from '@wiris/mathtype-html-integration-devkit/styles/icons/general/warn_icon.svg'

  export type IntegrationModelProperties = {
    configurationService: string
    target: HTMLElement
    scriptName: string
    environment: any
    callbackMethodArguments?: any
    version?: string | undefined
    editorObject?: any
    rtl?: boolean | undefined
    serviceProviderProperties?: any
    integrationParameters?: any
  }

  interface ServiceProviderProperties {
    URI?: string
    [key: string]: any
  }

  export default class IntegrationModel {
    language: string
    serviceProviderProperties: ServiceProviderProperties
    configurationService: string
    version: string
    target: HTMLElement | null
    scriptName?: string
    callbackMethodArguments: object
    environment: object
    isIframe: boolean
    editorObject: object
    rtl: boolean
    managesLanguage: boolean
    forcedHandMode: boolean
    temporalImageResizing: boolean
    core: Core | null
    listeners: Listeners
    offlineModal: HTMLElement
    offlineModalContent: HTMLElement
    offlineModalClose: HTMLElement
    offlineModalWarn: HTMLElement
    offlineModalMessage: HTMLElement
    offlineModalMessage1: HTMLElement
    offlineModalMessage2: HTMLElement

    constructor(integrationModelProperties: IntegrationModelProperties)

    init(): void

    getBrowser(): { detectedBrowser: string; versionBrowser: string }

    getOS(): { detectedOS: string; versionOS: string }

    getPath(): string

    getVersion(): string

    setLanguage(language: string): void

    setCore(core: Core): void

    getCore(): Core | null

    setTarget(target: HTMLElement): void

    setEditorObject(editorObject: object): void

    openNewFormulaEditor(): void

    openExistingFormulaEditor(): void

    updateFormula(mathml: string): string

    insertFormula(
      focusElement: HTMLElement,
      windowTarget: Window,
      mathml: string,
      wirisProperties: object | null
    ): { focusElement: HTMLElement; windowTarget: Window; node: HTMLElement; latex: string }

    getSelection(): Selection

    addEvents(): void

    removeEvents(): void

    destroy(): void

    doubleClickHandler(element: HTMLElement, event: MouseEvent): void
  }
}
